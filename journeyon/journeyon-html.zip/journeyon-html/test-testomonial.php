<div class="slick-item">
								<div class="testimonial-item">
									<img src="images/assets/quote.png" alt="">
									<p>Really useful app to find interesting things to see do, drink and eat in new places. I’ve been using it regularly in my travels over the past few months.</p>
									<h4>Kari Granleese</h4>
									<span>Traveler</span>
								</div>
							</div>